import{r as t}from"./react-Bx2quPv4.js";const o=500,s=(u=o)=>{const e=t.useRef(),r=()=>{e.current&&clearTimeout(e.current)};return t.useEffect(()=>()=>{r()},[]),c=>{r(),e.current=window.setTimeout(()=>{c(),r()},u)}};export{s as u};
//# sourceMappingURL=use-debounce-CExpsawk.js.map

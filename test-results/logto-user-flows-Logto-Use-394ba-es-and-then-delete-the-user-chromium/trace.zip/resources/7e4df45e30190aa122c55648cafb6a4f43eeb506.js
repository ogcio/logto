import{j as t}from"./react-Bx2quPv4.js";const s="__LS5v8__field",i="__kPWab__shimmer",n="__i9lo1__rotating",o={field:s,shimmer:i,rotating:n};function a({formFieldCount:e}){return t.jsx(t.Fragment,{children:Array.from({length:e}).map((m,r)=>t.jsx("div",{className:o.field},r))})}export{a as S};
//# sourceMappingURL=Skeleton-CDc_EEwr.js.map

import{q as e}from"./index-Drh_ikIS.js";const o=({quotaKey:t,usage:r,quota:s},u=!0)=>{if(!e)return!0;const i=s[t];return i===null?!0:typeof i=="boolean"?i:u?r<=i:r<i},n=t=>!o(t),c=t=>!o(t,!1);export{n as a,c as h};
//# sourceMappingURL=quota-DNH5Hbsm.js.map

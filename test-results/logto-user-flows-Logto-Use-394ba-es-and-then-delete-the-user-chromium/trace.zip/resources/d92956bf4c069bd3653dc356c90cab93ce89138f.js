import{bG as t}from"./index-Drh_ikIS.js";import{ee as o}from"./vendors-SRvjIlgA.js";const s=e=>(e?t(e):void 0)??o("admin_console.users.unnamed"),p=e=>{if(!(e!=null&&e.name))return;const{username:a,primaryEmail:m,primaryPhone:n}=e;return t({username:a,primaryEmail:m,primaryPhone:n})};export{p as a,s as g};
//# sourceMappingURL=user-DXOn5K02.js.map

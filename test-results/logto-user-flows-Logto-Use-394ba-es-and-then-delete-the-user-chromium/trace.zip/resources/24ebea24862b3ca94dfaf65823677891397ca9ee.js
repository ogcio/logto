const p=t=>/^https:\/\/[^.]+\.logto\.app\/api$/.test(t);export{p as i};
//# sourceMappingURL=management-api-CjmSfdZQ.js.map

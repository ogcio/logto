import{u as r,j as o}from"./react-Bx2quPv4.js";import{z as t}from"./index-Drh_ikIS.js";function i({className:s}){const{t:e}=r(void 0,{keyPrefix:"admin_console"});return o.jsx(t,{status:"error",className:s,children:e("user_details.suspended")})}export{i as S};
//# sourceMappingURL=index-geW75-Rt.js.map

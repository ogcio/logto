import{j as a}from"./react-Bx2quPv4.js";const r="__EmGwK__breakable",s={breakable:r};function t({children:e}){return a.jsx("div",{className:s.breakable,children:e})}export{t as B};
//# sourceMappingURL=index-DAGU9w1k.js.map

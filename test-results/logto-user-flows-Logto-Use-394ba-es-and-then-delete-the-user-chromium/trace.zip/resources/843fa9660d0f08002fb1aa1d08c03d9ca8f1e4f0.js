import{j as r}from"./react-Bx2quPv4.js";import{i,bH as n}from"./index-Drh_ikIS.js";function a({children:t}){return r.jsx(i,{href:n,children:t})}export{a as C};
//# sourceMappingURL=index-BuJLO7bU.js.map

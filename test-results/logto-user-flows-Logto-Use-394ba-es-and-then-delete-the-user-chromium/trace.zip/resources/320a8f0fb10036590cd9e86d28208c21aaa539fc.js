import{r as t}from"./react-Bx2quPv4.js";const i=e=>{const s=t.useRef(e);t.useEffect(()=>{s.current=e},[e]),t.useLayoutEffect(()=>{const r=n=>{s.current(n)};return r(),window.addEventListener("resize",r),()=>{window.removeEventListener("resize",r)}},[])};export{i as u};
//# sourceMappingURL=use-window-resize-DhwNm6By.js.map
